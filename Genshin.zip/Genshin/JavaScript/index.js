const { GenshinKit } = require('genshin-kit')
const App = new GenshinKit()
const cookie = '_mi18nLang=en-us; _ga=GA1.2.737819363.1622741882; _gid=GA1.2.685383449.1622741882; _MHYUUID=1638bb68-02c7-4d95-8816-13a2f63f3c41;'
App.loginWithCookie(cookie)
App.setServerType("os")
App.getUserInfo(701862760).then(console.log, console.error)
